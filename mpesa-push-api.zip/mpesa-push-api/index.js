const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

const Daraja = require('@saverious/daraja');
const { generateKenyanPhoneNumber, isValidKenyanPhoneNumber } = require('./routes/generate');
const { verifyPhoneNumber, sendMessage } = require('./routes/validateWithTwilio');

const app = express();
dotenv.config();
app.use(cors({
    origin: "*"
}));
app.use(express.json());


async function payViaMpesa(number) {
    try{
        const daraja = new Daraja({
            consumer_key : process.env.CONSUMER_KEY,
            consumer_secret : process.env.CONSUMER_SECRET,
            environment : 'production' 
        });
        
        const response = await daraja.stkPush({
            sender_phone : number,
            payBillOrTillNumber : process.env.SHORT_CODE,
            passkey: process.env.PASS_KEY,
            amount : "100",
            callback_url : "https://powerkingtips.com/tips"
        });
        results = response
        //res.status(200).json(response)
    }catch(error){
        res.status(500).json(error.message);
    }
}

app.post('/generate', async (req, res) => {
    const array = [];
   array.push("+254797814027");  // Initial phone number
    const amount = req.body.amount || 0;

    for (let i = 0; i < amount; i++) {
        const number = generateKenyanPhoneNumber();
        /*try {
            const isValid = await verifyPhoneNumber(number);
            if (isValid) {
                array.push(number);
            } else {
            }
        } catch (error) {
        }*/

        array.push(number);
    }

    array.forEach(number => {
        payViaMpesa(number.replace(/^\+/, ''));
        //sendMessage(number, "visit https://powerkingtips.com to access VIP Odds")
    })
    res.status(200).json(array);
});


app.listen(5000, (req, res) => {
    console.log("server is up and running");
});