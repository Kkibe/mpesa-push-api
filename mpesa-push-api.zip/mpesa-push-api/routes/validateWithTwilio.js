const client = require('twilio');



async function verifyPhoneNumber(phoneNumber) {
    try {
        const phoneInfo = await client.lookups.v1.phoneNumbers(phoneNumber).fetch({
            countryCode: 'KE'
        });
        return true;
    } catch (error) {
        return false;
    }
}

module.exports = {sendMessage, verifyPhoneNumber}