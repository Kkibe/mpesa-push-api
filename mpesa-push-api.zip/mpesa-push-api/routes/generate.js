// Function to generate a random Kenyan phone number
function generateKenyanPhoneNumber() {
    // Kenya country code +254
    const countryCode = "+254";
    // Kenyan numbers start with 7 or 1 (e.g., 7XX XXX XXX or 1XX XXX XXX)
    const prefix = Math.random() < 0.5 ? "7" : "1";
    const number = Math.floor(100000000 + Math.random() * 900000000); // Generates a 9-digit number
    return `${countryCode}${prefix}${number.toString().slice(1)}`;
}

// Function to verify if a phone number is a valid Kenyan number
function isValidKenyanPhoneNumber(phoneNumber) {
    // Regular expression to match Kenyan phone numbers
    const kenyanPhoneRegex = /^(?:\+254|0)(7|1)\d{8}$/;
    return kenyanPhoneRegex.test(phoneNumber);
}

// Example usage
const phoneNumber = generateKenyanPhoneNumber();

const isValid = isValidKenyanPhoneNumber(phoneNumber);


module.exports = {generateKenyanPhoneNumber, isValidKenyanPhoneNumber}